# Tiranga Backend – deployment checklist

1. Use a server/VPS with Docker installed.
2. Copy the `backend` folder to the server.
3. Change `TIRANGA_TOKEN_SECRET` to a random secret of at least 32 characters.
4. Run `docker compose up -d --build` from the backend folder.
5. Put an HTTPS reverse proxy (for example Caddy or Nginx) in front of port 8080.
6. Verify `/api/health` returns `{ "ok": true }` over HTTPS.
7. In `app/src/main/assets/backend-config.js`, set `enabled: true` and the HTTPS API URL ending in `/api`.
8. Open the Android project in Android Studio and build a signed release AAB.

Important: do not publish the Android app while the backend URL is still a placeholder.
