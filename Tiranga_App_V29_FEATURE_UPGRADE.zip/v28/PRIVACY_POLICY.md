# Tiranga App – Privacy Policy

**Draft for deployment review.** Replace the contact details and have the final policy reviewed before publishing.

Tiranga may process account information (such as name and email), videos uploaded by creators, likes, subscriptions and comments to provide the service. Uploaded videos are stored on the service's configured storage.

The app should not collect information that is not needed for its stated features. Users should be given a way to request account/data deletion where required by applicable law.

For privacy questions, contact: **[YOUR SUPPORT EMAIL]**

Effective date: **[DATE]**
