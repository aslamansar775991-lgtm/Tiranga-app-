# Tiranga V21 — Replit से मोबाइल Build

1. ZIP को Replit में import/upload करो।
2. Project खुलने के बाद ऊपर **Run** दबाओ।
3. Replit `tools/replit_build.sh` चलाएगा। पहली बार Android SDK और Gradle डाउनलोड होने में समय लग सकता है।
4. सफल build के बाद ये files मिलेंगी:
   - `app/build/outputs/apk/debug/app-debug.apk`
   - `app/build/outputs/bundle/release/app-release.aab`

Play Store पर publish करने से पहले release keystore/signing और live HTTPS backend configure करना जरूरी है।
