# Tiranga App – Terms of Service

**Draft for deployment review.** Replace placeholders and obtain appropriate legal review before publication.

Users must only upload content they have the right to share and must not upload unlawful, abusive, deceptive, or infringing material. Tiranga may remove content or restrict accounts when required by law or the service's moderation rules.

Creators are responsible for the content they upload. The service should provide reporting and moderation procedures before public launch.

Support contact: **[YOUR SUPPORT EMAIL]**
