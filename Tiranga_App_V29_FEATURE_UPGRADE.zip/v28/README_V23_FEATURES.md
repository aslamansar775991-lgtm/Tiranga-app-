# Tiranga App V23 — Feature Upgrade

This version extends V22 with practical in-app features: Trending sorting, channel filtering, playlists, add-to-playlist, notifications, reporting, playback speed, autoplay-next, theme toggle, history/watch-later clearing, hashtags/tags search, and creator-studio profile controls.

The project remains a WebView Android app. Online functions still require a configured HTTPS backend. Offline mode stores demo data locally.
