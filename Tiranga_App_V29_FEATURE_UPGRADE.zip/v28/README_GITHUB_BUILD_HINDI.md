# Tiranga App V28 — Replit के बिना Build

Replit की limit होने पर भी इस project को GitHub Actions से build किया जा सकता है।

## मोबाइल से करने के आसान चरण

1. GitHub में नया repository बनाइए।
2. इस पूरे project को repository में upload कीजिए।
3. `Actions` खोलिए।
4. `Tiranga Android Build` workflow चुनिए।
5. `Run workflow` दबाइए।
6. Build पूरा होने पर workflow के `Artifacts` में `tiranga-android-build` मिलेगा।
7. उसमें `app-debug.apk` फोन में test करने के लिए और `app-release.aab` Play Store के लिए मिलेगा।

## Public release से पहले

- `app/src/main/assets/backend-config.js` में अपना असली HTTPS backend URL डालना जरूरी है।
- `enabled: true` करना होगा।
- Backend का `/api/health` सही चलना चाहिए।
- Google Play के लिए अपना private signing keystore लगाना जरूरी है।
- Privacy Policy, Data Safety और Play Console की बाकी जानकारी सही भरनी होगी।

## जरूरी बात

यह workflow Replit पर निर्भर नहीं है। GitHub Actions cloud में Android build करता है।
