const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8080);
const MAX_UPLOAD = Number(process.env.MAX_UPLOAD_BYTES || 250 * 1024 * 1024);
const TOKEN_SECRET = process.env.TIRANGA_TOKEN_SECRET;
const HOST = process.env.HOST || '0.0.0.0';
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost';
const MAX_JSON_BYTES = Number(process.env.MAX_JSON_BYTES || 2 * 1024 * 1024);
const RATE_WINDOW_MS = Number(process.env.RATE_WINDOW_MS || 60 * 1000);
const RATE_LIMIT = Number(process.env.RATE_LIMIT || 120);
const rateBuckets = new Map();
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!TOKEN_SECRET || TOKEN_SECRET.length < 32) {
  console.warn('WARNING: set TIRANGA_TOKEN_SECRET to a random secret of at least 32 characters before deployment.');
}
const secret = TOKEN_SECRET || 'dev-only-secret-change-before-production-123456789';
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], videos: [], likes: [], subscriptions: [], comments: [] }, null, 2));

function db() { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
function save(x) { fs.writeFileSync(DB_FILE, JSON.stringify(x, null, 2)); }
function send(res, status, body, type = 'application/json', extra = {}) {
  const headers = {
    'Content-Type': type,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Access-Control-Allow-Origin': CORS_ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Video-Title, X-Video-Category',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    ...extra
  };
  res.writeHead(status, headers);
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let s = '';
    req.on('data', c => {
      s += c;
      if (s.length > MAX_JSON_BYTES) { reject(new Error('JSON body too large')); req.destroy(); }
    });
    req.on('end', () => { try { resolve(JSON.parse(s || '{}')); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}
function tokenFor(id) {
  const payload = Buffer.from(JSON.stringify({ id, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return payload + '.' + sig;
}
function auth(req) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return null;
  const token = h.slice(7);
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expected = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  if (sig.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const x = JSON.parse(Buffer.from(payload, 'base64url').toString());
    return x.exp > Date.now() ? x.id : null;
  } catch (e) { return null; }
}
function safeName(s) { return String(s || 'video').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80); }
function mediaType(file) { const ext = path.extname(file).toLowerCase(); return ext === '.webm' ? 'video/webm' : ext === '.mov' ? 'video/quicktime' : 'video/mp4'; }

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, '');
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const bucket = rateBuckets.get(ip);
  if (!bucket || now - bucket.started >= RATE_WINDOW_MS) rateBuckets.set(ip, { started: now, count: 1 });
  else if (++bucket.count > RATE_LIMIT) return send(res, 429, { error: 'too many requests' });
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && u.pathname === '/api/health') return send(res, 200, { ok: true, service: 'tiranga-backend', version: '2.9.0' });

    if (req.method === 'POST' && u.pathname === '/api/auth/login') {
      const b = await readJson(req);
      const name = String(b.name || '').trim();
      const email = String(b.email || '').trim().toLowerCase();
      if (!name || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { error: 'valid name and email are required' });
      const d = db();
      let user = d.users.find(x => x.email === email);
      if (!user) { user = { id: crypto.randomUUID(), name: name.slice(0, 60), email: email.slice(0, 160), createdAt: new Date().toISOString() }; d.users.push(user); save(d); }
      else if (name && user.name !== name.slice(0, 60)) { user.name = name.slice(0, 60); save(d); }
      return send(res, 200, { user, token: tokenFor(user.id) });
    }

    if (req.method === 'GET' && u.pathname === '/api/videos') {
      const d = db();
      return send(res, 200, { videos: d.videos.map(v => ({ ...v, url: `/media/${v.file}` })) });
    }

    if (req.method === 'POST' && u.pathname === '/api/videos') {
      const userId = auth(req); if (!userId) return send(res, 401, { error: 'login required' });
      const title = String(req.headers['x-video-title'] || '').trim();
      const category = String(req.headers['x-video-category'] || 'all').slice(0, 30);
      if (!title) return send(res, 400, { error: 'X-Video-Title is required' });
      const len = Number(req.headers['content-length'] || 0);
      if (len > MAX_UPLOAD) return send(res, 413, { error: 'video too large' });
      const file = safeName(Date.now() + '_' + title);
      const out = path.join(UPLOAD_DIR, file);
      let bytes = 0;
      const ws = fs.createWriteStream(out, { flags: 'wx' });
      let finished = false;
      const fail = (status, error) => { if (finished) return; finished = true; ws.destroy(); fs.rm(out, { force: true }, () => {}); send(res, status, { error }); };
      req.on('data', chunk => { bytes += chunk.length; if (bytes > MAX_UPLOAD) { req.destroy(new Error('too large')); fail(413, 'video too large'); } });
      req.on('error', () => fail(400, 'upload interrupted'));
      ws.on('error', () => fail(500, 'upload failed'));
      ws.on('finish', () => {
        if (finished) return;
        finished = true;
        const d = db();
        const creator = d.users.find(x => x.id === userId);
        const v = { id: crypto.randomUUID(), title: title.slice(0, 120), creator: creator?.name || 'Creator', category, views: 0, file, createdAt: new Date().toISOString() };
        d.videos.unshift(v); save(d);
        send(res, 201, { video: { ...v, url: `/media/${file}` } });
      });
      req.pipe(ws);
      return;
    }

    const actionMatch = u.pathname.match(/^\/api\/videos\/([^/]+)\/(like|subscribe)$/);
    if (req.method === 'POST' && actionMatch) {
      const userId = auth(req); if (!userId) return send(res, 401, { error: 'login required' });
      const videoId = actionMatch[1]; const action = actionMatch[2]; const d = db();
      if (!d.videos.some(v => v.id === videoId)) return send(res, 404, { error: 'video not found' });
      const arr = action === 'like' ? d.likes : d.subscriptions;
      const key = `${userId}:${videoId}`;
      const i = arr.indexOf(key);
      if (i >= 0) arr.splice(i, 1); else arr.push(key);
      save(d); return send(res, 200, { active: i < 0 });
    }

    const commentMatch = u.pathname.match(/^\/api\/videos\/([^/]+)\/comments$/);
    if (req.method === 'GET' && commentMatch) {
      const d = db(); return send(res, 200, { comments: d.comments.filter(c => c.videoId === commentMatch[1]) });
    }
    if (req.method === 'POST' && commentMatch) {
      const userId = auth(req); if (!userId) return send(res, 401, { error: 'login required' });
      const b = await readJson(req); const text = String(b.text || '').trim();
      if (!text) return send(res, 400, { error: 'text required' });
      const d = db(); if (!d.videos.some(v => v.id === commentMatch[1])) return send(res, 404, { error: 'video not found' });
      const c = { id: crypto.randomUUID(), videoId: commentMatch[1], userId, text: text.slice(0, 500), createdAt: new Date().toISOString() };
      d.comments.push(c); save(d); return send(res, 201, { comment: c });
    }

    if (req.method === 'GET' && u.pathname.startsWith('/media/')) {
      const file = safeName(path.basename(u.pathname.slice(7))); const p = path.join(UPLOAD_DIR, file);
      if (!fs.existsSync(p)) return send(res, 404, { error: 'not found' });
      const st = fs.statSync(p); const type = mediaType(file); const range = req.headers.range;
      if (range) {
        const m = range.match(/bytes=(\d*)-(\d*)/);
        if (m) {
          const start = m[1] ? Number(m[1]) : 0;
          const end = m[2] ? Math.min(Number(m[2]), st.size - 1) : Math.min(start + 1024 * 1024 - 1, st.size - 1);
          if (start <= end && start < st.size) return res.writeHead(206, { 'Content-Type': type, 'Content-Length': end - start + 1, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': CORS_ORIGIN }) && fs.createReadStream(p, { start, end }).pipe(res);
        }
        return send(res, 416, { error: 'invalid range' }, 'application/json', { 'Content-Range': `bytes */${st.size}` });
      }
      res.writeHead(200, { 'Content-Type': type, 'Content-Length': st.size, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': CORS_ORIGIN });
      return fs.createReadStream(p).pipe(res);
    }
    return send(res, 404, { error: 'not found' });
  } catch (e) { console.error(e); return send(res, 500, { error: 'server error' }); }
});
server.listen(PORT, HOST, () => console.log(`Tiranga backend listening on http://${HOST}:${PORT}`));
