# Tiranga Backend V2

Dependency-free Node.js starter backend for the Tiranga Android app.

## Run locally
1. Install Node.js 20+.
2. Set `TIRANGA_TOKEN_SECRET` to a long random value.
3. Run `node server.js`.
4. For Android testing, use an HTTPS public API URL in `app/src/main/assets/backend-config.js`.

## Endpoints
- `GET /api/health`
- `POST /api/auth/login` JSON `{name,email}`
- `GET /api/videos`
- `POST /api/videos` raw video body with `Authorization`, `X-Video-Title`, `X-Video-Category`
- `POST /api/videos/:id/like`
- `POST /api/videos/:id/subscribe`
- `GET/POST /api/videos/:id/comments`
- `GET /media/:filename` (supports HTTP byte ranges for video playback)

## Public deployment
This is a launch starter, not a finished production platform. Before public launch, use a managed database and object storage/CDN, HTTPS, proper authentication/email verification, moderation/reporting, abuse/rate limiting, backups, account deletion, privacy policy, terms, and legal review.
