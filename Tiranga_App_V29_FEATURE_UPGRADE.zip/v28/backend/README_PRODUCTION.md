# Production deployment

1. Set a strong `TIRANGA_TOKEN_SECRET` (32+ random characters).
2. Set `CORS_ORIGIN` to the exact HTTPS origin(s) that should call the API; do not leave `*` for a credentialed production client.
3. Persist `backend/data` and `backend/uploads`.
4. Put the backend behind HTTPS/reverse proxy.
5. Test `/api/health`, login, upload, playback, like, subscribe and comments.
6. Add backups, monitoring, rate limiting, malware/content moderation and abuse reporting before a public creator platform launch.
