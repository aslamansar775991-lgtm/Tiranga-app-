#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ ! -x ./gradlew ]]; then
  echo "Gradle wrapper executable is missing. Open the project in Android Studio and sync Gradle, then run: ./gradlew bundleRelease"
  exit 3
fi
./gradlew clean bundleRelease
AAB="app/build/outputs/bundle/release/app-release.aab"
if [[ -f "$AAB" ]]; then echo "AAB created: $AAB"; else echo "Build finished but AAB was not found."; exit 4; fi
