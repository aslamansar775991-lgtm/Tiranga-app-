#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
CACHE="$ROOT/.cache/replit-build"
SDK="$CACHE/android-sdk"
GRADLE="$CACHE/gradle-8.9"
mkdir -p "$CACHE"

export JAVA_HOME="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")}"
export ANDROID_SDK_ROOT="$SDK"
export ANDROID_HOME="$SDK"
export PATH="$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$SDK/build-tools/35.0.0:$PATH"

if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  mkdir -p "$SDK/cmdline-tools"
  tmp="$CACHE/cmdline-tools.zip"
  curl -L --fail --retry 3 -o "$tmp" https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  rm -rf "$CACHE/cmdline-tools-unpacked"
  mkdir -p "$CACHE/cmdline-tools-unpacked"
  unzip -q "$tmp" -d "$CACHE/cmdline-tools-unpacked"
  rm -rf "$SDK/cmdline-tools/latest"
  mv "$CACHE/cmdline-tools-unpacked/cmdline-tools" "$SDK/cmdline-tools/latest"
fi

yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"

if [ ! -x "$GRADLE/bin/gradle" ]; then
  curl -L --fail --retry 3 -o "$CACHE/gradle.zip" https://services.gradle.org/distributions/gradle-8.9-bin.zip
  rm -rf "$CACHE/gradle-8.9-unpacked"
  mkdir -p "$CACHE/gradle-8.9-unpacked"
  unzip -q "$CACHE/gradle.zip" -d "$CACHE/gradle-8.9-unpacked"
  rm -rf "$GRADLE"
  mv "$CACHE/gradle-8.9-unpacked/gradle-8.9" "$GRADLE"
fi

"$GRADLE/bin/gradle" --no-daemon clean assembleDebug bundleRelease

echo ""
echo "===== BUILD SUCCESSFUL ====="
echo "APK: $ROOT/app/build/outputs/apk/debug/app-debug.apk"
echo "AAB: $ROOT/app/build/outputs/bundle/release/app-release.aab"
