#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo "Usage: $0 https://your-domain.example/api"; exit 1; fi
URL="$1"
case "$URL" in
  https://*/api|https://*/api/) ;;
  *) echo "Backend URL must start with https:// and end with /api"; exit 2;;
esac
python3 - "$URL" <<'PY'
from pathlib import Path
import sys
u=sys.argv[1].rstrip('/')
p=Path('app/src/main/assets/backend-config.js')
s=p.read_text()
s=s.replace('enabled: false,','enabled: true,').replace('https://YOUR-HTTPS-BACKEND-DOMAIN/api',u)
p.write_text(s)
print('Backend configured:', u)
PY
