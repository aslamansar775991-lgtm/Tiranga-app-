# Tiranga App 2.1.0 — Release checklist

1. Deploy `backend/` behind HTTPS (Render blueprint included in `render.yaml`).
2. Confirm `/api/health` returns `ok: true`.
3. Set `CORS_ORIGIN` to the actual allowed origin.
4. Set `backend-config.js` to the deployed HTTPS `/api` URL and enable it.
5. Build a signed release AAB with your private keystore.
6. Test login, video upload/playback, likes, subscriptions, comments, logout, reinstall/update and network failures.
7. Complete Play Console app-content, privacy, data-safety and other required declarations accurately.

Important: the included JSON-file database is a starter implementation. For a high-traffic public service, move user/video metadata to a managed database and video files to object storage/CDN before launch at scale.
