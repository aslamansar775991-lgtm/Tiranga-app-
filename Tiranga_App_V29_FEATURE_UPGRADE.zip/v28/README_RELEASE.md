# Tiranga App 2.1.0 (V21) — Release Preparation

## Android signed AAB
Use Android Studio or a machine with the Android SDK and Gradle to run:
`./gradlew :app:bundleRelease`

For signing, configure these environment variables:
- TIRANGA_KEYSTORE
- TIRANGA_KEYSTORE_PASSWORD
- TIRANGA_KEY_ALIAS
- TIRANGA_KEY_PASSWORD

The release build only uses the signing config when TIRANGA_KEYSTORE is present. Never commit a keystore or passwords.

## GitHub Actions
The included workflow is prepared for a release keystore supplied through GitHub Secrets. Required secrets:
- TIRANGA_KEYSTORE_BASE64
- TIRANGA_KEYSTORE_PASSWORD
- TIRANGA_KEY_ALIAS
- TIRANGA_KEY_PASSWORD

## Backend
Deploy `backend/` behind HTTPS, then set `enabled: true` and the real HTTPS API URL in `app/src/main/assets/backend-config.js`.

## Play Store
Before publishing, complete the store listing, app icon/screenshots, privacy-policy URL, terms URL, content rating, support contact, and testing/release checks.
