# TIRANGA V21 — मोबाइल से Build

यह प्रोजेक्ट GitHub Actions से अपने-आप Android build करने के लिए तैयार है।

## क्या बनेगा
- Debug APK: `app-debug.apk` — फोन में टेस्ट करने के लिए
- Release AAB: `app-release.aab` — Google Play पर publish करने के लिए

## जरूरी
Play Store release के लिए अपना signing key/keystore इस्तेमाल करें।

## Backend
`app/src/main/assets/backend-config.js` में असली HTTPS backend URL डालने के बाद ही public release करें।
