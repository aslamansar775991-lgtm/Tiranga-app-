window.TIRANGA_BACKEND = {
  enabled: false,
  apiBaseUrl: "https://YOUR-HTTPS-BACKEND-DOMAIN/api"
};
