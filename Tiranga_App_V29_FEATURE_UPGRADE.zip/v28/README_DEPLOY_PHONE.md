# Tiranga 2.1.0 — Mobile-friendly deployment path

This project contains the Android client and a Node.js backend.

## A. Deploy backend
1. Create a GitHub repository and upload this project folder.
2. Create a Render Web Service from that repository.
3. Use the included `render.yaml` as the deployment blueprint, or set Runtime to Docker and Dockerfile to `backend/Dockerfile`.
4. Set `CORS_ORIGIN` to the app origin you actually use. Do not paste secrets into source files.
5. After deployment, open `/api/health`. It must return JSON with `ok: true`.

## B. Connect Android app
Edit `app/src/main/assets/backend-config.js`:

```
window.TIRANGA_BACKEND = {
  enabled: true,
  apiBaseUrl: "https://YOUR-BACKEND-DOMAIN/api"
};
```

The URL must use HTTPS in production.

## C. Build release AAB
Open the project root in Android Studio and run:

`./gradlew bundleRelease`

Output:
`app/build/outputs/bundle/release/app-release.aab`

Use your own release keystore. Never put the keystore or passwords in GitHub.

## D. Before public launch
Test on at least two Android devices: login, upload, playback, like, subscribe, comments, logout, reinstall/update, and poor-network behavior. Also verify that your privacy policy, terms, data retention, moderation and age-related policies accurately describe the live service.
