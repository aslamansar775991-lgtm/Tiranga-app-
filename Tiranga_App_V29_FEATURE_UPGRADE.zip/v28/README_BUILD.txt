# TIRANGA APP V21

Android client + Node.js backend.

## Android build

This project is prepared for Gradle 8.9 and Android SDK 35.

### Android Studio (recommended)
1. Open the `tiranga_v19` folder in Android Studio.
2. Let Android Studio sync/download Gradle 8.9 and the Android SDK components.
3. Select **Build > Generate Signed Bundle / APK**.
4. For Play Store, choose **Android App Bundle (AAB)** and create/use your own signing key.

### Command line
After Gradle 8.9 is installed:
`./gradlew :app:bundleRelease`

Output:
`app/build/outputs/bundle/release/app-release.aab`

## Backend

Configure `backend/.env`, deploy the backend behind HTTPS, then put the real API URL in `app/src/main/assets/backend-config.js`.

The app intentionally stays in local/offline demo mode until a real backend URL is configured.
