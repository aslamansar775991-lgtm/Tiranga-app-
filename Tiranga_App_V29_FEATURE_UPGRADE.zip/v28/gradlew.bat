@echo off
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle %*
  exit /b %errorlevel%
)
echo Gradle 8.9 is required. Open this project in Android Studio and let Gradle sync, or install Gradle 8.9 and rerun this script.
exit /b 3
