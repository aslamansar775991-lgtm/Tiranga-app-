# Tiranga App V28 — ऑनलाइन चालू करने की प्रक्रिया

## अभी क्या तैयार है
- Android project: V28
- GitHub Actions: APK और AAB cloud build
- Backend: Node.js API
- Render deployment blueprint: `render.yaml`
- Health check: `/api/health`
- Login, video upload/playback, like, subscribe और comments के online API
- Uploads को persistent backend data disk के अंदर रखा गया है

## Replit की जरूरत नहीं है
Replit limit होने पर GitHub + Render इस्तेमाल करें। दोनों में अपने account से sign in करना होगा।

## चरण 1 — Backend online करें
1. GitHub में repository बनाइए।
2. इस project की सभी files upload करें।
3. Render में repository connect करके `render.yaml` से deploy करें।
4. `TIRANGA_TOKEN_SECRET` को Render में कम-से-कम 32 characters का random secret रखें।
5. Deploy के बाद `/api/health` खोलें। `ok: true` दिखना चाहिए।

## चरण 2 — App को backend से जोड़ें
`app/src/main/assets/backend-config.js` में:
- `enabled: false` को `enabled: true` करें।
- `apiBaseUrl` में Render के असली HTTPS address के आगे `/api` लगाएँ।

उदाहरण format:
`https://आपका-backend-address.onrender.com/api`

## चरण 3 — APK test करें
GitHub → Actions → `Tiranga Android Build` → `Run workflow`।
Build पूरा होने पर Artifacts से `app-debug.apk` लेकर फोन में test करें।

## चरण 4 — Public release
पहले online APK से login, upload, playback, like, subscribe और comments test करें। फिर private signing key से release AAB बनाकर Google Play Console में publish करें।

## जरूरी बात
यहाँ से हम ZIP और configuration तैयार कर सकते हैं, लेकिन आपके GitHub/Render account में sign-in करके वास्तविक deployment आपके account से ही करना होगा। Password या secret key चैट में न भेजें।
