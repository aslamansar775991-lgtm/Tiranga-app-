# Tiranga V28 — 92 Feature Upgrade

92-feature registry plus additional local UI interactions for player controls, captions/transcript demo, PiP, loop, theater mode, copy link, comment sorting/reply, language, restricted mode, data saver and account security.

Live streaming, memberships, monetization, copyright/Content ID, CDN/storage and server-side moderation still require production backend services.
